# browse-meter
A chrome extension to track how many times you visit popular websites.
